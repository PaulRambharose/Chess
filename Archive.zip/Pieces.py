def print_board(board):
    for item in range(9):
        print(
            f'{board[item][0]} | {board[item][1]} | {board[item][2]} | {board[item][3]} | {board[item][4]} | {board[item][5]} | {board[item][6]} | {board[item][7]} | {board[item][8]} | ')
    print('\n')


# legality checks to see if a piece is asked to move in the way it should. The function itself will consider a move to be legal even if
# the square it wants to move to is occupied by its own color, this issue is covered in the chess.py program execution.
def legality_of_move(piece, square, board, updated_color_board, piece_behavior):
    okay = 0  # if okay is 1, the move is legal
    ro, colu = square  # ro and colu are the square to move to in array coordinates
    if ro > -1 and colu > -1 and ro < 9 and colu < 9:  # if the chosen square is actually on the board
        for row in range(8):
            for col in range(8):
                if board[row][
                    col] == piece:  # find the piece to move, row and col are its current location in array coordinates
                    if piece == '♞ 1' or piece == '♞ 2' or piece == '♘ 1' or piece == '♘ 2' or piece_behavior == 'knight':
                        if ((ro == row + 2 or ro == row - 2) and (colu == col + 1 or colu == col - 1)) or (
                                (ro == row + 1 or ro == row - 1) and (colu == col + 2 or colu == col - 2)):
                            okay = 1  # if it moves like a horse, in the L-shape, it is a legal move
                    if piece == '♖ 1' or piece == '♖ 2' or piece == '♜ 1' or piece == '♜ 2' or piece_behavior == 'rook':
                        if ro > row and col == colu:
                            for sqre in range(1,
                                              ro - row):  # check to make sure the squares between the current and desired are empty
                                if updated_color_board[row + sqre][col] != ' ':
                                    return okay
                            okay = 1
                        # if it moves like a rook, and it is not blocked by any piece in between the squares of interest, it is legal
                        if ro < row and col == colu:
                            for sqre in range(1,
                                              row - ro):  # check to make sure the squares between the current and desired are empty
                                if updated_color_board[ro + sqre][col] != ' ':
                                    return okay
                            okay = 1
                        if colu > col and ro == row:
                            for sqre in range(1,
                                              colu - col):  # check to make sure the squares between the current and desired are empty
                                if updated_color_board[row][col + sqre] != ' ':
                                    return okay
                            okay = 1
                        if colu < col and ro == row:
                            for sqre in range(1,
                                              col - colu):  # check to make sure the squares between the current and desired are empty
                                if updated_color_board[row][colu + sqre] != ' ':
                                    return okay
                            okay = 1
                    if piece == '♝ 1' or piece == '♝ 2' or piece == '♗ 1' or piece == '♗ 2' or piece_behavior == 'bishop':
                        for n in range(8):
                            if ro == row + n and colu == col - n:  # bishops only move diagonally
                                for sqre in range(1,
                                                  n):  # check to make sure the squares between the current and desired are empty
                                    if updated_color_board[row + sqre][col - sqre] != ' ':
                                        return okay
                                okay = 1
                                # if it moves like a bishop, and it is not blocked by any piece in between the squares of interest, it is legal
                            if ro == row - n and colu == col - n:  # bishops only move diagonally
                                for sqre in range(1,
                                                  n):  # check to make sure the squares between the current and desired are empty
                                    if updated_color_board[row - sqre][col - sqre] != ' ':
                                        return okay
                                okay = 1
                            if ro == row + n and colu == col + n:  # bishops only move diagonally
                                for sqre in range(1,
                                                  n):  # check to make sure the squares between the current and desired are empty
                                    if updated_color_board[row + sqre][col + sqre] != ' ':
                                        return okay
                                okay = 1
                            if ro == row - n and colu == col + n:  # bishops only move diagonally
                                for sqre in range(1,
                                                  n):  # check to make sure the squares between the current and desired are empty
                                    if updated_color_board[row - sqre][col + sqre] != ' ':
                                        return okay
                                okay = 1
                    if piece_behavior == 'whitepawn':
                        if colu == col and ro == row - 1:  # pawns can only move forward if the space is empty
                            if updated_color_board[ro][colu] == ' ':
                                okay = 1
                        if ro == row - 1 and (colu == col - 1 or colu == col + 1):  # if pawn moves diagonally:
                            if updated_color_board[ro][colu] == 'B':  # they must eat an opposing piece
                                okay = 1
                        if row == 6 and ro == 4 and col == colu:
                            if updated_color_board[4][col] == ' ' and updated_color_board[5][col] == ' ':
                                okay = 1
                    if piece_behavior == 'blackpawn':
                        if colu == col and ro == row + 1:  # pawns can only move forward if the space is empty
                            if updated_color_board[ro][colu] == ' ':
                                okay = 1
                        if ro == row + 1 and (colu == col - 1 or colu == col + 1):  # if pawn moves diagonally:
                            if updated_color_board[ro][colu] == 'W':  # they must eat an opposing piece
                                okay = 1
                        if row == 1 and ro == 3 and col == colu:  # pawn may move forward two squares in starting position
                            if updated_color_board[2][col] == ' ' and updated_color_board[3][col] == ' ':
                                okay = 1
                    if piece == 'B ♕' or piece == 'W ♛' or piece_behavior == 'queen':  # the queen is essentially a bishop+rook
                        if ro == row or col == colu:  # if you move laterally: use rook code
                            if ro > row:
                                for sqre in range(1, ro - row):
                                    if updated_color_board[row + sqre][col] != ' ':
                                        return okay
                                okay = 1

                            if ro < row:
                                for sqre in range(1, row - ro):
                                    if updated_color_board[ro + sqre][col] != ' ':
                                        return okay
                                okay = 1
                            if colu > col:
                                for sqre in range(1, colu - col):
                                    if updated_color_board[row][col + sqre] != ' ':
                                        return okay
                                okay = 1
                            if colu < col:
                                for sqre in range(1, col - colu):
                                    if updated_color_board[row][colu + sqre] != ' ':
                                        return okay
                                okay = 1
                        if row != ro and col != colu:  # if you move diagonally: use bishop code
                            for n in range(8):
                                if (ro == row + n and colu == col - n):
                                    for sqre in range(1, n):
                                        if updated_color_board[row + sqre][col - sqre] != ' ':
                                            return okay
                                    okay = 1
                                if (ro == row - n and colu == col - n):
                                    for sqre in range(1, n):
                                        if updated_color_board[row - sqre][col - sqre] != ' ':
                                            return okay
                                    okay = 1
                                if (ro == row + n and colu == col + n):
                                    for sqre in range(1, n):
                                        if updated_color_board[row + sqre][col + sqre] != ' ':
                                            return okay
                                    okay = 1
                                if (ro == row - n and colu == col + n):
                                    for sqre in range(1, n):
                                        if updated_color_board[row - sqre][col + sqre] != ' ':
                                            return okay
                                    okay = 1
                    if piece == 'B ♔' or piece == 'W ♚':
                        if row - 1 <= ro <= row + 1 and col - 1 <= colu <= col + 1:
                            okay = 1
    return okay

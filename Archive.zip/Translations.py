def piece_assign(piece, color):  # sets player piece input to correct piece
    if color == 'white':
        if piece == 'knight1' or piece == 'horse1':
            piece = '♞ 1'
        if piece == 'knight2' or piece == 'horse2':
            piece = '♞ 2'
        if piece == 'rook1' or piece == 'castle 1':
            piece = '♜ 1'
        if piece == 'rook2' or piece == 'castle 2':
            piece = '♜ 2'
        if piece == 'king' or piece == 'King':
            piece = 'W ♚'
        if piece == 'queen' or piece == 'Queen':
            piece = 'W ♛'
        if piece == 'bishop1' or piece == 'Bishop 1':
            piece = '♝ 1'
        if piece == 'bishop2' or piece == 'Bishop 2':
            piece = '♝ 2'
        if piece == 'pawn1' or piece == 'Pawn1':
            piece = '♟ 1'
        if piece == 'pawn2' or piece == 'Pawn2':
            piece = '♟ 2'
        if piece == 'pawn3' or piece == 'Pawn3':
            piece = '♟ 3'
        if piece == 'pawn4' or piece == 'Pawn4':
            piece = '♟ 4'
        if piece == 'pawn5' or piece == 'Pawn5':
            piece = '♟ 5'
        if piece == 'pawn6' or piece == 'Pawn6':
            piece = '♟ 6'
        if piece == 'pawn7' or piece == 'Pawn7':
            piece = '♟ 7'
        if piece == 'pawn8' or piece == 'Pawn8':
            piece = '♟ 8'
    if color == 'black':
        if piece == 'knight1' or piece == 'horse1':
            piece = '♘ 1'
        if piece == 'knight2' or piece == 'horse2':
            piece = '♘ 2'
        if piece == 'rook1' or piece == 'castle 1':
            piece = '♖ 1'
        if piece == 'rook2' or piece == 'castle 2':
            piece = '♖ 2'
        if piece == 'king' or piece == 'King':
            piece = 'B ♔'
        if piece == 'queen' or piece == 'Queen':
            piece = 'B ♕'
        if piece == 'bishop1' or piece == 'Bishop 1':
            piece = '♗ 1'
        if piece == 'bishop2' or piece == 'Bishop 2':
            piece = '♗ 2'
        if piece == 'pawn1' or piece == 'Pawn1':
            piece = '♙ 1'
        if piece == 'pawn2' or piece == 'Pawn2':
            piece = '♙ 2'
        if piece == 'pawn3' or piece == 'Pawn3':
            piece = '♙ 3'
        if piece == 'pawn4' or piece == 'Pawn4':
            piece = '♙ 4'
        if piece == 'pawn5' or piece == 'Pawn5':
            piece = '♙ 5'
        if piece == 'pawn6' or piece == 'Pawn6':
            piece = '♙ 6'
        if piece == 'pawn7' or piece == 'Pawn7':
            piece = '♙ 7'
        if piece == 'pawn8' or piece == 'Pawn8':
            piece = '♙ 8'
    return piece


def square_establish(string):  # sets player square input to list coordinates
    column, row = string
    if column == 'a' or column == 'A':
        column = 0
    if column == 'b' or column == 'B':
        column = 1
    if column == 'c' or column == 'C':
        column = 2
    if column == 'd' or column == 'D':
        column = 3
    if column == 'e' or column == 'E':
        column = 4
    if column == 'f' or column == 'F':
        column = 5
    if column == 'g' or column == 'G':
        column = 6
    if column == 'h' or column == 'H':
        column = 7
    if row == '8' or row == '8':
        row = 0
    if row == '7' or row == '7':
        row = 1
    if row == '6' or row == '6':
        row = 2
    if row == '5' or row == '5':
        row = 3
    if row == '4' or row == '4':
        row = 4
    if row == '3' or row == '3':
        row = 5
    if row == '2' or row == '2':
        row = 6
    if row == '1' or row == '1':
        row = 7
    return row, column

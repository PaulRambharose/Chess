from Pieces import legality_of_move


class king():
    def king_square(self, board, color_board, current):  # this is meant to find the king square
        for row in range(8):
            for col in range(8):
                if board[row][col] == 'B ♔' or board[row][col] == 'W ♚':  # find a king
                    if color_board[row][col] == current:  # find the correct king, 'B' or 'W'
                        return row, col  # return king location

    def under_attack(self, board, color_board, square, attacking_color, pawns_list, pawn_behavior_list):
        attacked = 0  # this function can tell if any square is under attack, square is an array of row, column
        attackers = ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']  # this stores the attackers
        index = 0
        i = 0
        the_pieces = ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']
        for a in range(8):
            for b in range(8):
                if color_board[a][b] == attacking_color:
                    the_pieces[i] = board[a][b]  # go through entire board to look at all enemy pieces
                    i += 1
        piece_behavior = 'notpawn'
        for piece in the_pieces:
            i = 0
            for row in range(8):
                for col in range(8):
                    if board[row][col] == piece and piece != '':  # find the piece location
                        for pawn in pawns_list:
                            if piece == pawn:
                                piece_behavior = pawn_behavior_list[i]
                            i += 1
                        if piece == '♞ 1' or piece == '♞ 2' or piece == '♘ 1' or piece == '♘ 2' or piece == '♖ 1' or piece == '♖ 2' or piece == '♜ 1' or piece == '♜ 2' or piece == 'B ♕' or piece == 'W ♛' or piece == '♝ 1' or piece == '♝ 2' or piece == '♗ 1' or piece == '♗ 2' or piece == 'B ♔' or piece == 'W ♚':
                            piece_behavior = 'notpawn'
                        if legality_of_move(piece, square, board,
                                            color_board, piece_behavior) == 1:  # if square is attacked by that piece
                            attacked = 1  # under_attack/legality will return a 1 for attacker if a piece is defending one of it's own at the square as well
                            attackers[index] = piece  # stores all attackers of the square
                            index += 1
        return attacked, attackers  # attacked=1 means piece is attacked, attackers list stores the pieces attacking

    def cannot_move_anywhere(self, board, color_board, opposite_color, current_color, king_piece_attacked, pawns_list,
                             pawn_behavior_list):
        king_row = self.king_square(board, color_board, current_color)[0]  # current_color here is the attacked king
        king_column = self.king_square(board, color_board, current_color)[1]
        rowdown = [king_row + 1, king_column]
        rowup = [king_row - 1, king_column]
        colright = [king_row, king_column + 1]
        colleft = [king_row, king_column - 1]
        upleft = [rowup[0], colleft[1]]
        upright = [rowup[0], colright[1]]
        downleft = [rowdown[0], colleft[1]]
        downright = [rowdown[0],
                     colright[1]]  # these 8 lines provide the array coordinates of the squares around the king
        squares_around_king = [rowdown, rowup, colleft, colright, upleft, upright, downleft, downright]
        index = 0
        squares_around_king_filtered = [[], [], [], [], [], [], [], []]
        for square in squares_around_king:
            if -1 < square[0] < 8 and -1 < square[1] < 8:
                squares_around_king_filtered[index] = square
                index += 1
        for square in squares_around_king_filtered:
            if square != []:
                row, col = square
                if color_board[row][col] == ' ':
                    board[row][col] = king_piece_attacked
                    color_board[row][col] = current_color
                    board[king_row][king_column] = '   '
                    color_board[king_row][king_column] = ' '
                    if self.under_attack(board, color_board, square, opposite_color, pawns_list, pawn_behavior_list)[
                        0] == 0:  # if a square is not under attack
                        board[row][col] = '   '
                        color_board[row][col] = ' '
                        board[king_row][king_column] = king_piece_attacked
                        color_board[king_row][king_column] = current_color
                        return 0  # return that the king can move somewhere legally
                    else:
                        board[row][col] = '   '
                        color_board[row][col] = ' '
                        board[king_row][king_column] = king_piece_attacked
                        color_board[king_row][king_column] = current_color
                if color_board[row][col] == opposite_color:
                    if self.under_attack(board, color_board, square, opposite_color, pawns_list,
                                         pawn_behavior_list) == 0:
                        return 0
        return 1  # return that the king cannot move anywhere

    def can_block_check(self, board, color_board, opposite_color, current, pawns_list, pawn_behavior_list):
        king_square = ro, colu = self.king_square(board, color_board, current)  # find king square
        pawn_behavior = 'notpawn'
        if self.under_attack(board, color_board, king_square, opposite_color, pawns_list, pawn_behavior_list)[
            0] == 1:  # if in check
            attacker = \
            self.under_attack(board, color_board, king_square, opposite_color, pawns_list, pawn_behavior_list)[
                1]  # get list of attackers
            i = 0
            for pawn in pawns_list:
                if attacker[0] == pawn:
                    pawn_behavior = pawn_behavior_list[i]
                    break
                i += 1
            if attacker[1] == '' and attacker[0]!=board[ro][colu] and (
                    attacker[0] == '♖ 1' or attacker[0] == '♖ 2' or attacker[0] == '♜ 1' or attacker[
                0] == '♜ 2' or pawn_behavior == 'rook'):
                # if the only attacker is a rook
                for row in range(8):
                    for col in range(8):
                        if board[row][col] == attacker[0]:  # find attacker's location
                            # check to see if check can be blocked
                            if ro > row:
                                for sqre in range(1,
                                                  ro - row):  # check to make sure the squares between the king and rook are blockable
                                    square = [row + sqre, col]
                                    if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != '' or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                        return 1  # if any square is under attack, the check is blockable
                                return 0  # if no square is under attack, the king must move
                            if ro < row:
                                for sqre in range(1,
                                                  row - ro):
                                    square = [ro + sqre, col]
                                    if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                        return 1
                                return 0
                            if col > colu:
                                for sqre in range(1,
                                                  col - colu):
                                    square = [row, colu + sqre]
                                    if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                        return 1
                                return 0
                            if col < colu:
                                for sqre in range(1,
                                                  colu - col):
                                    square = [row, col + sqre]
                                    if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                        return 1
                                return 0
            elif attacker[1] == '' and attacker[0]!=board[ro][colu] and(
                    attacker[0] == '♗ 1' or attacker[0] == '♗ 2' or attacker[0] == '♝ 1' or attacker[
                0] == '♝ 2' or pawn_behavior == 'bishop'):
                # if the only attacker is a bishop
                for row in range(8):
                    for col in range(8):
                        if board[row][col] == attacker[0]:
                            for n in range(8):
                                if ro == row + n and colu == col - n:  # bishops only move diagonally
                                    for sqre in range(1,
                                                      n):  # check to see if the squares between the king and bishop are attacked
                                        square = [row + sqre, colu + sqre]
                                        if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                            return 1
                                    return 0
                                if ro == row - n and colu == col - n:  # bishops only move diagonally
                                    for sqre in range(1,
                                                      n):  # check to see if the squares between the king and bishop are attacked
                                        square = [ro + sqre, colu + sqre]
                                        if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                            return 1
                                    return 0
                                if ro == row + n and colu == col + n:  # bishops only move diagonally
                                    for sqre in range(1,
                                                      n):  # check to see if the squares between the king and bishop are attacked
                                        square = [row + sqre, col + sqre]
                                        if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                            return 1
                                    return 0
                                if ro == row - n and colu == col + n:  # bishops only move diagonally
                                    for sqre in range(1,
                                                      n):  # check to see if the squares between the king and bishop are attacked
                                        square = [ro + sqre, col + sqre]
                                        if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                            return 1
                                    return 0
            elif attacker[1] == '' and attacker[0]!=board[ro][colu] and(
                    attacker[0] == 'B ♕' or attacker[0] == 'W ♛' or pawn_behavior == 'queen'):
                for row in range(8):
                    for col in range(8):
                        if board[row][col] == attacker[0]:
                            if row == ro or col == colu:  # if the check is from same row or column, use rook code
                                if ro > row:
                                    for sqre in range(1,
                                                      ro - row):  # check to make sure the squares between the king and queen are blockable
                                        square = [row + sqre, col]
                                        if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                            return 1  # if any square is under attack, the check is blockable
                                    return 0  # if no square is under attack, the king must move
                                if ro < row:
                                    for sqre in range(1,
                                                      row - ro):
                                        square = [ro + sqre, col]
                                        if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                            return 1
                                    return 0
                                if col > colu:
                                    for sqre in range(1,
                                                      col - colu):
                                        square = [row, colu + sqre]
                                        if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                            return 1
                                    return 0
                                if col < colu:
                                    for sqre in range(1,
                                                      colu - col):
                                        square = [row, col + sqre]
                                        if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                            return 1
                                    return 0
                            if row != ro and col != colu:  # use bishop code
                                for n in range(8):
                                    if ro == row + n and colu == col - n:  # bishops only move diagonally
                                        for sqre in range(1,
                                                          n):  # check to see if the squares between the king and queen are attacked
                                            square = [row + sqre, colu + sqre]
                                            if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                                return 1
                                        return 0
                                    if ro == row - n and colu == col - n:  # bishops only move diagonally
                                        for sqre in range(1,
                                                          n):  # check to see if the squares between the king and queen are attacked
                                            square = [ro + sqre, colu + sqre]
                                            if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                                return 1
                                        return 0
                                    if ro == row + n and colu == col + n:  # bishops only move diagonally
                                        for sqre in range(1,
                                                          n):  # check to see if the squares between the king and queen are attacked
                                            square = [row + sqre, col + sqre]
                                            if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                                return 1
                                        return 0
                                    if ro == row - n and colu == col + n:  # bishops only move diagonally
                                        for sqre in range(1,
                                                          n):  # check to see if the squares between the king and queen are attacked
                                            square = [ro + sqre, col + sqre]
                                            if (self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != board[ro][colu]  and self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][0] != ''or self.under_attack(board, color_board, square, current, pawns_list,
                                                         pawn_behavior_list)[1][1] != ''):
                                                return 1
                                        return 0
            else:
                return 0

    def draw(self, board, color_board, paralyzed_color, drawing_color, paralyzed_king, pawns_list, pawn_behavior_list):
        king_square = self.king_square(board, color_board, paralyzed_color)  # find immobile king
        king_immobility = self.cannot_move_anywhere(board, color_board, drawing_color, paralyzed_color,
                                                    paralyzed_king, pawns_list,
                                                    pawn_behavior_list)  # make sure it is immobile
        king_in_check = \
        self.under_attack(board, color_board, king_square, drawing_color, pawns_list, pawn_behavior_list)[
            0]  # check if immobile king is in check
        pawns_cannot_move = 0
        pinnable=0
        pinned=0
        print(paralyzed_color)
        if king_immobility == 1 and king_in_check == 0:  # if the king cannot move anywhere but is not in check
            for row in range(8):
                for col in range(8):
                        index = 0
                        piece = board[row][col]
                        if (piece == '♞ 1' or piece == '♞ 2' or piece == '♘ 1' or piece == '♘ 2' or piece == '♖ 1' or piece == '♖ 2' or \
                                piece == '♜ 1' or piece == '♜ 2' or piece == 'B ♕' or piece == 'W ♛' or piece == '♝ 1' or piece == '♝ 2' or piece == '♗ 1'\
                                or piece == '♗ 2') and color_board[row][col] == paralyzed_color:
                            pinnable = 1
                        if color_board[row][col] == paralyzed_color and piece!='W ♚' and piece!='B ♔':
                            board[row][col] = '   '
                            color_board[row][col] = ' '
                            if self.under_attack(board, color_board, king_square, drawing_color, pawns_list,
                                                 pawn_behavior_list)[0] == 1:
                                pinned = 1
                            else:
                                pinned = 0
                            board[row][col] = piece
                            color_board[row][col] = paralyzed_color
                        piece_behavior='notpawn'
                        for pawn in pawns_list:
                            if piece == pawn:
                                piece_behavior = pawn_behavior_list[index]
                            if color_board[row][col] == paralyzed_color and (
                                    piece_behavior == 'blackpawn' or piece_behavior == 'whitepawn'):
                                if paralyzed_color == 'B':  # if a pawn can move, return that there is no draw
                                    if color_board[row + 1][col] == '   ' or color_board[row + 1][
                                        col - 1] == drawing_color or color_board[row + 1][col + 1] == drawing_color:
                                        return 0  # there is no draw
                                    else:
                                        pawns_cannot_move = 1
                                if paralyzed_color == 'W':
                                    if color_board[row - 1][col] == '   ' or color_board[row - 1][
                                        col - 1] == drawing_color or color_board[row - 1][col + 1] == drawing_color:
                                        return 0
                                    else:
                                        pawns_cannot_move = 1
                            index += 1
            correct_pawns=['','','','','','','','']
            i=0
            for row in range(8):
                for col in range(8):
                    index=0
                    for pawn in pawns_list:
                        if board[row][col]==pawn and color_board[row][col]==paralyzed_color and (pawn_behavior_list[index]=='blackpawn' or pawn_behavior_list[index]=='whitepawn'):
                            correct_pawns[i]=pawn
                            i+=1
                        index+=1
            if correct_pawns[0]=='':
                pawns_cannot_move=1

            if pawns_cannot_move == 1 and ((pinned == 1 and pinnable == 1) or pinnable == 0):  # if pawns cannot move and there are no other pieces or those pieces are pinned:
                return 1  # return a draw
        return 0

    # this next function is for permitting castling
    def castling(self, board, color_board, opposite_color, current_color, rook_piece, movement_of_king,
                 movement_of_rook, pawns_list, pawn_behavior_list):
        king_square = self.king_square(board, color_board, current_color)  # find king
        king_col = king_square[1]
        allow = 0
        if movement_of_king == 0 and movement_of_rook == 0 and \
                self.under_attack(board, color_board, king_square, opposite_color, pawns_list, pawn_behavior_list)[
                    0] == 0:  # if rook and king have not moved and king is not in check
            for ro in range(8):
                for colu in range(8):
                    if board[ro][colu] == rook_piece:
                        row = ro  # save the location of the rook
                        col = colu
            if king_col < col:  # if the rook is to the right of the king
                squares_to_check = [[row, 5], [row, 6]]
                for square in squares_to_check:
                    if self.under_attack(board, color_board, square, opposite_color, pawns_list, pawn_behavior_list)[
                        0] == 0 and color_board[row][5] == ' ' and color_board[row][6] == ' ':
                        allow = 1
                    else:
                        return 0
            if king_col > col:  # if the rook is to the left of the king
                squares_to_check = [[row, 2], [row, 3]]
                for square in squares_to_check:
                    if self.under_attack(board, color_board, square, opposite_color, pawns_list, pawn_behavior_list)[
                        0] == 0 and color_board[row][2] == ' ' and color_board[row][3] == ' ' and color_board[row][
                        1] == ' ':
                        allow = 1
                    else:
                        return 0
        return allow

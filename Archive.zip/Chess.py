from Pieces import print_board
from Translations import square_establish
from Pieces import legality_of_move
from Translations import piece_assign
from KingOps import king

board = [
    ['♖ 1', '♘ 1', '♗ 1', 'B ♕', 'B ♔', '♗ 2', '♘ 2', '♖ 2', '8'],
    ['♙ 1', '♙ 2', '♙ 3', '♙ 4', '♙ 5', '♙ 6', '♙ 7', '♙ 8', '7'],
    ['   ', '   ', '   ', '   ', '   ', '   ', '   ', '   ', '6'],
    ['   ', '   ', '   ', '   ', '   ', '   ', '   ', '   ', '5'],
    ['   ', '   ', '   ', '   ', '   ', '   ', '   ', '   ', '4'],
    ['   ', '   ', '   ', '   ', '   ', '   ', '   ', '   ', '3'],
    ['♟ 1', '♟ 2', '♟ 3', '♟ 4', '♟ 5', '♟ 6', '♟ 7', '♟ 8', '2'],
    ['♜ 1', '♞ 1', '♝ 1', 'W ♛', 'W ♚', '♝ 2', '♞ 2', '♜ 2', '1'],
    [' a ', ' b ', ' c ', ' d ', ' e ', ' f ', ' g ', ' h ', ' ']
]
color_board = [
    ['B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', '8'], ['B', 'B', 'B', 'B', 'B', 'B', 'B', 'B', '7'],
    [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '6'], [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '5'],
    [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '4'], [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '3'],
    ['W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', '2'], ['W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', '1'],
    ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', ' ']
]

# these two lists are for promoting pawns, the lists correspond to a single pawn piece and how it moves. The piece on the board will not update.
pawns = ['♙ 1', '♙ 2', '♙ 3', '♙ 4', '♙ 5', '♙ 6', '♙ 7', '♙ 8', '♟ 1', '♟ 2', '♟ 3', '♟ 4', '♟ 5', '♟ 6', '♟ 7', '♟ 8']
pawn_behavior = ['blackpawn', 'blackpawn', 'blackpawn', 'blackpawn', 'blackpawn', 'blackpawn', 'blackpawn', 'blackpawn',
                 'whitepawn', 'whitepawn', 'whitepawn', 'whitepawn', 'whitepawn', 'whitepawn', 'whitepawn', 'whitepawn',
                 'notpawn']


def move(piece, square, confirmation, king_square, opposite, current):
    if confirmation != 'N' and confirmation != 'n':  # if player decides to confirm move
        sqware = ro, colu = square_establish(square)  # this is the square to move the piece to in array coordinates
        indek = 0
        for pawn in pawns:
            if piece == pawn:
                break
            indek += 1
        if color_board[ro][colu] != current:  # if square to move to has a piece of player's color, the move is illegal
            if legality_of_move(piece, sqware, board,
                                color_board, pawn_behavior[
                                    indek]) == 1:  # check to make sure the square is on the board and piece moves that way
                for row in range(8):
                    for col in range(8):
                        if board[row][col] == piece:  # row and col are the current piece location in array coordinates
                            board[row][col] = '   '  # set the original location blank
                            saved_current = color_board[row][col]
                            color_board[row][col] = ' '  # set the original location blank
                            saved_row = row  # saved variables are meant to undo a move if it leaves the king in check
                            saved_col = col
                saved_piece = board[ro][colu]
                board[ro][colu] = piece  # put the piece in its new location
                saved_color = color_board[ro][colu]
                color_board[ro][colu] = current  # put the piece in its new location
                if piece == 'B ♔' or piece == 'W ♚':  # if the king moved, update the king_square list
                    king_square = [ro, colu]
                if player == 'black':
                    if blackking.under_attack(board, color_board, king_square, opposite, pawns, pawn_behavior)[
                        0] == 1:  # if player's king is in check after move was made
                        print("Illegal Move: The King Is In Danger After That Move")
                        board[saved_row][saved_col] = piece  # put the piece back
                        color_board[saved_row][saved_col] = saved_current  # put the piece back
                        board[ro][colu] = saved_piece  # reset the square it was moved to
                        color_board[ro][colu] = saved_color  # reset the square it was moved to
                if player == 'white':
                    if whiteking.under_attack(board, color_board, king_square, opposite, pawns, pawn_behavior)[
                        0] == 1:
                        print(
                            "Illegal Move: The King Is In Danger After That Move")
                        board[saved_row][saved_col] = piece
                        color_board[saved_row][saved_col] = saved_current
                        board[ro][colu] = saved_piece
                        color_board[ro][colu] = saved_color
            else:
                print("Illegal Move")
    print_board(board)


blackking = king()  # create a class for each king
whiteking = king()
print("\nCase-sensitive Syntax to enter piece: knight1, rook1, king, queen, bishop2, pawn7, etc.")
print("Case-sensitive Syntax to enter new position: a7, b5, e7, g4, etc.")
print("To castle, choose king and pick the square two to the right/left of it's starting position.\n")
print_board(board)
p = 1
blackking_square = [0, 4]
blackmovement_of_rook1 = 0  # these are for approving a castling
blackmovement_of_rook2 = 0
whitemovement_of_rook1 = 0
whitemovement_of_rook2 = 0
whitemovement_of_king = 0
blackmovement_of_king = 0
while (1):
    try:
        if p == 1:  # p allows player to still move if an illegal move was entered before
            player = 'white'
            opposite = 'B'
            current = 'W'
            if color_board[7][0] != 'W':
                whitemovement_of_rook1 = 1
            if color_board[7][7] != 'W':
                whitemovement_of_rook2 = 1
            if color_board[7][4] != 'W':
                whitemovement_of_king = 1
            for row in range(8):  # find the white king_square
                for col in range(8):
                    if board[row][col] == 'W ♚':
                        whiteking_square = [row, col]
            if whiteking.under_attack(board, color_board, whiteking_square, opposite, pawns, pawn_behavior)[
                0] == 1:  # if player is in check
                print("The White king is in check...")
            piece = input("White Enter piece: ")
            piece = piece_assign(piece, player)  # convert typed piece to symbol
            square = input("Enter new position: ")
            ro, colu = square_establish(square)
            if ro == 7 and (colu == 6 or colu == 2) and piece == 'W ♚' and whitemovement_of_king == 0:  # castling
                if colu == 6:
                    side = 'king'
                    allow = whiteking.castling(board, color_board, opposite, current, '♜ 2', whitemovement_of_king,
                                               whitemovement_of_rook2, pawns, pawn_behavior)
                if colu == 2:
                    side = 'queen'
                    allow = whiteking.castling(board, color_board, opposite, current, '♜ 1', whitemovement_of_king,
                                               whitemovement_of_rook1, pawns, pawn_behavior)
                if allow == 1:
                    board[ro][colu] = piece
                    color_board[ro][colu] = 'W'
                    board[7][4] = '   '
                    color_board[7][4] = ' '
                    if colu == 2:
                        board[ro][3] = '♜ 1'
                        color_board[ro][3] = 'W'
                        board[7][0] = '   '
                        color_board[7][0] = ' '
                    if colu == 6:
                        board[ro][5] = '♜ 2'
                        color_board[ro][5] = 'W'
                        board[7][7] = '   '
                        color_board[7][7] = ' '
                    print_board(board)
                else:
                    print(
                        f"Illegal Move. Castle on {side}side unavailable. Relevant square(s) blocked/attacked or relevant piece(s) moved 1+ times.")
            else:  # every other move
                move(piece, square, input("Confirm move? Input enter or n: "), whiteking_square, opposite, current)
            if board[ro][colu] == piece:  # if piece has been moved, move onto next player
                p = 2
                # look for upgrade for pawns
                ind = 0
                for pawn in pawns:
                    if piece == pawn:
                        if ro == 0 and color_board[ro][colu] == 'W' and pawn_behavior[ind] == 'whitepawn':
                            behavior = input(f"What would you like to upgrade {piece} to?\n"
                                             f"Choose between: queen, rook, knight, bishop: ")
                            print(f'\n\nRemember that {piece} now moves like a {behavior}\n\n')
                            if behavior[0] == 'q' or behavior[0] == 'Q':
                                behavior = 'queen'
                            if behavior[0] == 'k' or behavior[0] == 'K':
                                behavior = 'knight'
                            if behavior[0] == 'r' or behavior[0] == 'R':
                                behavior = 'rook'
                            if behavior[0] == 'b' or behavior[0] == 'B':
                                behavior = 'bishop'
                            pawn_behavior[ind] = behavior  # update how the pawn is allowed to move
                            break
                    ind += 1
                # look for checkmate now
                if blackking.under_attack(board, color_board, blackking_square, current, pawns, pawn_behavior)[
                    0] == 1:  # if black is in check
                    cannot_move = blackking.cannot_move_anywhere(board, color_board, current,
                                                                 opposite, 'B ♔', pawns,
                                                                 pawn_behavior)  # check if black king cannot move
                    can_block = blackking.can_block_check(board, color_board, current,
                                                          opposite, pawns,
                                                          pawn_behavior)  # check if blackking can block a check
                    attacking_piece = \
                        blackking.under_attack(board, color_board, blackking_square, current, pawns, pawn_behavior)[
                            1]  # find black's attacker
                    for ro in range(8):
                        for colu in range(8):
                            if board[ro][colu] == attacking_piece[0]:
                                attacker_square = ro, colu
                                can_eat = blackking.under_attack(board, color_board, attacker_square, opposite, pawns,
                                                                 pawn_behavior)[0]  # check if black can eat attacker
                                if blackking.under_attack(board, color_board, attacker_square, 'B', pawns, pawn_behavior)[1][0]=='B ♔' and blackking.under_attack(board, color_board, attacker_square, 'B', pawns, pawn_behavior)[1][1]=='' and cannot_move==1:
                                    can_eat = 0 #if the attacker is the king and king cannot eat, they cannot eat
                                if attacking_piece[1] != '':  # if the king is attacked twice, it must be moved
                                    can_eat = 0
                    if cannot_move == 1 and can_block == 0 and can_eat == 0:
                        print("White Wins by Checkmate!")
                        exit(0)
            for row in range(8):  # find the white king_square
                for col in range(8):
                    if board[row][col] == 'W ♚':
                        whiteking_square = [row, col]
            if whiteking.draw(board, color_board, opposite, current, 'B ♔', pawns, pawn_behavior) == 1:
                print("Draw by Stalemate")
                exit(0)
        if p == 2:
            player = 'black'
            opposite = 'W'
            current = 'B'
            if color_board[0][0] != 'B':
                blackmovement_of_rook1 = 1
            if color_board[0][7] != 'B':
                blackmovement_of_rook2 = 1
            if color_board[0][4] != 'B':
                blackmovement_of_king = 1
            for row in range(8):
                for col in range(8):
                    if board[row][col] == 'B ♔':
                        blackking_square = [row, col]
            if blackking.under_attack(board, color_board, blackking_square, opposite, pawns, pawn_behavior)[0] == 1:
                print("The Black king is in check...")
            piece = input("Black Enter piece: ")
            piece = piece_assign(piece, player)
            square = input("Enter new position: ")
            ro, colu = square_establish(square)
            if ro == 0 and (colu == 6 or colu == 2) and piece == 'B ♔' and blackmovement_of_king == 0:  # castling
                if colu == 6:
                    side = 'king'
                    allow = blackking.castling(board, color_board, opposite, current, '♖ 2', blackmovement_of_king,
                                               blackmovement_of_rook2, pawns, pawn_behavior)
                if colu == 2:
                    side = 'queen'
                    allow = blackking.castling(board, color_board, opposite, current, '♖ 1', blackmovement_of_king,
                                               blackmovement_of_rook1, pawns, pawn_behavior)
                if allow == 1:
                    board[ro][colu] = piece
                    color_board[ro][colu] = 'B'
                    board[0][4] = '   '
                    color_board[0][4] = ' '
                    if colu == 2:
                        board[ro][3] = '♖ 1'
                        color_board[ro][3] = 'B'
                        board[0][0] = '   '
                        color_board[0][0] = ' '
                    if colu == 6:
                        board[ro][5] = '♖ 2'
                        color_board[ro][5] = 'B'
                        board[0][7] = '   '
                        color_board[0][7] = ' '
                    print_board(board)
                else:
                    print(
                        f"Illegal Move. Castle on {side}side unavailable. Relevant square(s) blocked/attacked or relevant piece(s) moved 1+ times.")
            else:  # every other move
                move(piece, square, input("Confirm move? Input enter or n: "), blackking_square, opposite, current)
            if board[ro][colu] == piece:
                p = 1
                # look for pawn upgrades
                ind = 0
                for pawn in pawns:
                    if piece == pawn:
                        if ro == 7 and color_board[ro][colu] == 'B' and pawn_behavior[ind] == 'blackpawn':
                            behavior = input(f"What would you like to upgrade {piece} to?"
                                             f"Choose between: queen, rook, knight, bishop: ")
                            if behavior[0] == 'q' or behavior[0] == 'Q':
                                behavior = 'queen'
                            if behavior[0] == 'k' or behavior[0] == 'K':
                                behavior = 'knight'
                            if behavior[0] == 'r' or behavior[0] == 'R':
                                behavior = 'rook'
                            if behavior[0] == 'b' or behavior[0] == 'B':
                                behavior = 'bishop'
                            pawn_behavior[ind] = behavior  # update how the pawn is allowed to move
                            break
                    ind += 1
                # look for checkmate now
                if whiteking.under_attack(board, color_board, whiteking_square, current, pawns, pawn_behavior)[
                    0] == 1:  # if white is in check
                    cannot_move = whiteking.cannot_move_anywhere(board, color_board, current,
                                                                 opposite, 'W ♚', pawns,
                                                                 pawn_behavior)  # opposite here is the attacked king
                    can_block = whiteking.can_block_check(board, color_board, current,
                                                          opposite, pawns,
                                                          pawn_behavior)  # check if white king can block a check
                    attacking_piece = \
                        whiteking.under_attack(board, color_board, whiteking_square, current, pawns, pawn_behavior)[
                            1]  # find attacker
                    for ro in range(8):
                        for colu in range(8):
                            if board[ro][colu] == attacking_piece[0]:
                                attacker_square = ro, colu
                                can_eat = whiteking.under_attack(board, color_board, attacker_square, opposite, pawns,
                                                                 pawn_behavior)[
                                    0]  # check if white can eat attacker
                                if blackking.under_attack(board, color_board, attacker_square, 'W', pawns, pawn_behavior)[1][0]=='W ♚' and blackking.under_attack(board, color_board, attacker_square, 'W', pawns, pawn_behavior)[1][1]=='' and cannot_move==1:
                                    can_eat = 0 #if the attacker is the king and king cannot eat, they cannot eat
                                if attacking_piece[1] != '':  # if the king is attacked twice, it must be moved
                                    can_eat = 0
                    print(cannot_move,can_block,can_eat)
                    if cannot_move == 1 and can_block == 0 and can_eat == 0:
                        print("Black Wins by Checkmate!")
                        exit(0)
            for row in range(8):  # update the king's square to find checkmate on next turn
                for col in range(8):
                    if board[row][col] == 'B ♔':
                        blackking_square = [row, col]
            if blackking.draw(board, color_board, opposite, current, 'W ♚', pawns, pawn_behavior) == 1:
                print("Draw by Stalemate")
                exit(0)
    except ValueError:  # this is for incorrect inputs
        print("Incorrect Input(s) Syntax")
    except TypeError:
        print("Incorrect Input(s) Syntax")
    except KeyboardInterrupt:
        pass
